/* USER CODE BEGIN Header */
/**
 * GABY Y VIC NUCLEO 2
 */
/* USER CODE END Header */
#include "main.h"
#include "fatfs.h"

/* USER CODE BEGIN Includes */
#include "fatfs_sd.h"
#include "ili9341.h"
#include <string.h>
#include <stdio.h>
#include <stdint.h>
/* USER CODE END Includes */

/* USER CODE BEGIN PD */
#define FONDO        0x0823
#define AZUL_OSCURO  0x11EB
#define TARJETA      0x1989
#define BLANCO       0xFFFF
#define CYAN         0x07FF
#define VERDE        0x07E0
#define AMARILLO     0xFFE0
#define GRIS         0xBDF7
#define BARRA        0x318C
#define ROJO         0xF800
#define CMD_LONGITUD 32
/* USER CODE END PD */

I2C_HandleTypeDef hi2c1;
SPI_HandleTypeDef hspi1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
static FATFS fs;
static FIL archivo;
// AHT10: direccion I2C de 7 bits 0x38, o 0x39 en algunas placas.
// HAL usa la direccion desplazada un bit (p.ej. 0x38 << 1).
static uint16_t aht10_direccion = 0;
static HAL_StatusTypeDef aht10_ultimo_estado = HAL_ERROR;
static uint8_t sensor_disponible = 0;
static uint8_t medicion_valida = 0;
static uint8_t hay_actual = 0;
static uint8_t hay_anterior = 0;
static float temp_actual = 0.0f;
static float temp_anterior = 0.0f;
static float ultima_temperatura = 0.0f;

// Recepcion por interrupciones: UART2 (PC) y UART3 (Nucleo 1).
typedef struct {
    char datos[CMD_LONGITUD];
    volatile uint8_t longitud;
    volatile uint8_t listo;
    volatile uint32_t ultimo_byte_ms;
} RX_Comando;
static RX_Comando rx_pc = {0}, rx_n1 = {0};
static uint8_t byte_pc, byte_n1;
/* USER CODE END PV */

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART3_UART_Init(void);

/* USER CODE BEGIN 0 */
static void UART_Enviar(UART_HandleTypeDef *uart, const char *s)
{
    HAL_UART_Transmit(uart, (uint8_t *)s, (uint16_t)strlen(s), 500);
}

static void Temperatura_Texto(float temperatura, char *texto)
{
    int32_t centesimas = (int32_t)(temperatura * 100.0f +
                                  (temperatura >= 0 ? 0.5f : -0.5f));
    uint32_t absoluto = centesimas < 0 ?
        (uint32_t)(-(int64_t)centesimas) : (uint32_t)centesimas;
    snprintf(texto, 24, "%s%lu.%02lu", centesimas < 0 ? "-" : "",
             (unsigned long)(absoluto / 100),
             (unsigned long)(absoluto % 100));
}

static void Pantalla_Estado(const char *estado, uint16_t color)
{
    FillRect(151, 182, 149, 17, TARJETA);
    LCD_Print((char *)estado, 151, 184, 1, color, TARJETA);
}

static void Pantalla_Inicio(void)
{
    // La pantalla es PARALELA, SPI1 es solo para la microSD.
    HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);
    LCD_Init();
    LCD_Clear(FONDO);
    FillRect(0, 0, 320, 38, AZUL_OSCURO);
    LCD_Print("BIO DATA LOGGER", 12, 10, 2, BLANCO, AZUL_OSCURO);
    FillRect(280, 12, 5, 14, CYAN);
    FillRect(290, 17, 5, 9, CYAN);
    FillRect(300, 9, 5, 17, CYAN);
    FillRect(10, 46, 300, 119, TARJETA);
    LCD_Print("TEMPERATURA", 20, 56, 2, CYAN, TARJETA);
    LCD_Print("TEMP ACTUAL", 20, 80, 1, GRIS, TARJETA);
    LCD_Print("TEMP ANTERIOR", 145, 80, 1, GRIS, TARJETA);
    LCD_Print("--.--", 20, 99, 1, BLANCO, TARJETA);
    LCD_Print("--.--", 145, 99, 1, BLANCO, TARJETA);
    Rect(102, 99, 5, 5, BLANCO);
    LCD_Print("C", 112, 99, 1, CYAN, TARJETA);
    Rect(227, 99, 5, 5, BLANCO);
    LCD_Print("C", 237, 99, 1, CYAN, TARJETA);
    LCD_Print("0 C", 20, 123, 1, GRIS, TARJETA);
    LCD_Print("50 C", 198, 123, 1, GRIS, TARJETA);
    FillRect(20, 141, 210, 13, BARRA);
    for (int i = 1; i < 5; i++)
        V_line(20 + i * 42, 141, 13, FONDO);
    FillRect(270, 75, 18, 56, CYAN);
    FillRect(274, 79, 10, 49, TARJETA);
    FillRect(266, 125, 26, 25, CYAN);
    FillRect(271, 130, 16, 15, TARJETA);
    FillRect(10, 174, 300, 57, TARJETA);
    FillRect(21, 186, 9, 9, AMARILLO);
    LCD_Print("ESTADO", 40, 184, 1, BLANCO, TARJETA);
    LCD_Print("ESPERANDO DATOS", 151, 184, 1, AMARILLO, TARJETA);
    H_line(20, 204, 280, BARRA);
    LCD_Print("SISTEMA DE MONITOREO", 72, 213, 1, CYAN, TARJETA);
}

static void Pantalla_ActualizarTemperaturas(void)
{
    char texto[24];
    FillRect(20, 97, 80, 20, TARJETA);
    FillRect(145, 97, 80, 20, TARJETA);
    if (hay_actual) {
        Temperatura_Texto(temp_actual, texto);
        LCD_Print(texto, 20, 99, 1, BLANCO, TARJETA);
    }
    if (hay_anterior) {
        Temperatura_Texto(temp_anterior, texto);
        LCD_Print(texto, 145, 99, 1, BLANCO, TARJETA);
    } else {
        LCD_Print("--.--", 145, 99, 1, BLANCO, TARJETA);
    }
    int ancho = (int)(temp_actual * 210.0f / 50.0f);
    if (ancho < 0) ancho = 0;
    if (ancho > 210) ancho = 210;
    FillRect(20, 141, 210, 13, BARRA);
    if (ancho > 0) FillRect(20, 141, ancho, 13, CYAN);
    for (int i = 1; i < 5; i++)
        V_line(20 + i * 42, 141, 13, FONDO);
    FillRect(274, 79, 10, 49, TARJETA);
    int altura = ancho * 49 / 210;
    if (altura > 0) FillRect(274, 128 - altura, 10, altura, CYAN);
    FillRect(271, 130, 16, 15, CYAN);
}

/* Inicio del sensor AHT10 por I2C1. No utiliza registros ni
 * coeficientes de calibracion de BMP280/BME280. */
static uint8_t AHT10_Iniciar(void)
{
    const uint8_t direcciones[] = {0x38, 0x39};
    uint8_t estado = 0;
    uint8_t iniciar[3] = {0xE1, 0x08, 0x00};

    aht10_direccion = 0;
    HAL_Delay(100); // Esperar estabilizacion tras energizar el AHT10.

    for (uint8_t i = 0; i < sizeof(direcciones); i++) {
        uint16_t dir_hal = ((uint16_t)direcciones[i]) << 1;
        aht10_ultimo_estado = HAL_I2C_IsDeviceReady(
            &hi2c1, dir_hal, 3, 100);
        if (aht10_ultimo_estado == HAL_OK) {
            aht10_direccion = dir_hal;
            break;
        }
    }
    if (aht10_direccion == 0) return 0;

    // Leer byte de estado para comprobar calibracion (bit 3).
    aht10_ultimo_estado = HAL_I2C_Master_Receive(
        &hi2c1, aht10_direccion, &estado, 1, 100);
    if (aht10_ultimo_estado != HAL_OK) return 0;

    if ((estado & 0x08u) == 0u) {
        // Inicializacion especifica del AHT10 (NO usar 0xBE de AHT20).
        aht10_ultimo_estado = HAL_I2C_Master_Transmit(
            &hi2c1, aht10_direccion, iniciar, 3, 100);
        if (aht10_ultimo_estado != HAL_OK) return 0;
        HAL_Delay(30);

        aht10_ultimo_estado = HAL_I2C_Master_Receive(
            &hi2c1, aht10_direccion, &estado, 1, 100);
        if (aht10_ultimo_estado != HAL_OK) return 0;
        if ((estado & 0x08u) == 0u) return 0;
    }
    return 1;
}

/* Lee una conversion del AHT10. Retorna 1 si la temperatura es valida.
 * Respuesta: [status, RH19..12, RH11..4, RH3..0|T19..16, T15..8, T7..0]
 * T(°C) = (dato_T20 / 2^20) * 200 - 50.
 */
static uint8_t AHT10_LeerTemperatura(float *temperatura)
{
    uint8_t comando[3] = {0xAC, 0x33, 0x00};
    uint8_t datos[6];
    uint8_t lista = 0;

    if (temperatura == NULL || aht10_direccion == 0) return 0;

    aht10_ultimo_estado = HAL_I2C_Master_Transmit(
        &hi2c1, aht10_direccion, comando, sizeof(comando), 100);
    if (aht10_ultimo_estado != HAL_OK) return 0;

    // La conversion requiere al menos 75-80 ms.
    HAL_Delay(85);
    for (uint8_t intento = 0; intento < 10; intento++) {
        aht10_ultimo_estado = HAL_I2C_Master_Receive(
            &hi2c1, aht10_direccion, datos, sizeof(datos), 100);
        if (aht10_ultimo_estado != HAL_OK) return 0;
        if ((datos[0] & 0x80u) == 0u) {
            lista = 1;
            break;
        }
        HAL_Delay(10);
    }
    if (!lista) return 0;

    uint32_t temperatura_raw = (((uint32_t)datos[3] & 0x0Fu) << 16) |
                               ((uint32_t)datos[4] << 8) |
                               (uint32_t)datos[5];
    *temperatura = (200.0f * (float)temperatura_raw / 1048576.0f) - 50.0f;
    return 1;
}

static uint8_t Adquirir_Temperatura(void)
{
    float nueva;
    if (!sensor_disponible) sensor_disponible = AHT10_Iniciar();
    if (!sensor_disponible) {
        Pantalla_Estado("ERROR SENSOR", ROJO);
        return 0;
    }
    Pantalla_Estado("LEYENDO...", AMARILLO);
    if (!AHT10_LeerTemperatura(&nueva)) {
        Pantalla_Estado("ERROR LECTURA", ROJO);
        return 0;
    }
    if (hay_actual) { temp_anterior = temp_actual; hay_anterior = 1; }
    temp_actual = nueva;
    ultima_temperatura = nueva;
    medicion_valida = 1;
    hay_actual = 1;
    Pantalla_ActualizarTemperaturas();
    Pantalla_Estado("LECTURA OK", VERDE);
    return 1;
}

static FRESULT SD_GuardarTemperatura(void)
{
    if (!medicion_valida) return FR_INVALID_OBJECT;
    // La pantalla es paralela: SPI1 exclusivamente para SD.
    HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);
    FRESULT res = f_mount(&fs, USERPath, 1);
    if (res != FR_OK) return res;

    res = f_open(&archivo, "0:/TEMP.CSV", FA_OPEN_ALWAYS | FA_WRITE);
    if (res == FR_OK) {
        UINT escritos = 0;
        FRESULT paso;
        paso = f_lseek(&archivo, f_size(&archivo));
        if (paso == FR_OK && f_size(&archivo) == 0) {
            const char cabecera[] = "temperatura,unidad\r\n";
            UINT n = (UINT)(sizeof(cabecera) - 1);
            paso = f_write(&archivo, cabecera, n, &escritos);
            if (paso == FR_OK && escritos != n) paso = FR_DISK_ERR;
        }
        if (paso == FR_OK) {
            char texto[24], linea[48];
            Temperatura_Texto(ultima_temperatura, texto);
            int largo = snprintf(linea, sizeof(linea), "%s,C\r\n", texto);
            if (largo <= 0 || largo >= (int)sizeof(linea)) {
                paso = FR_INVALID_PARAMETER;
            } else {
                paso = f_write(&archivo, linea, (UINT)largo, &escritos);
                if (paso == FR_OK && escritos != (UINT)largo)
                    paso = FR_DISK_ERR;
            }
        }
        FRESULT cierre = f_close(&archivo);
        res = (paso == FR_OK) ? cierre : paso;
    }
    FRESULT desmontar = f_mount(NULL, USERPath, 0);
    if (res == FR_OK) res = desmontar;
    HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);
    return res;
}

static FRESULT SD_VerArchivo(UART_HandleTypeDef *uart)
{
    FRESULT res = f_mount(&fs, USERPath, 1);
    if (res != FR_OK) return res;
    res = f_open(&archivo, "0:/TEMP.CSV", FA_READ);
    if (res == FR_OK) {
        char datos[65];
        UINT leidos;
        UART_Enviar(uart, "\r\n--- TEMP.CSV ---\r\n");
        do {
            res = f_read(&archivo, datos, 64, &leidos);
            if (res == FR_OK && leidos > 0)
                HAL_UART_Transmit(uart, (uint8_t *)datos, (uint16_t)leidos, 500);
        } while (res == FR_OK && leidos == 64);
        FRESULT cierre = f_close(&archivo);
        if (res == FR_OK) res = cierre;
        UART_Enviar(uart, "\r\n--- FIN ---\r\n");
    }
    FRESULT desmontar = f_mount(NULL, USERPath, 0);
    if (res == FR_OK) res = desmontar;
    return res;
}

static void ProcesarComando(const char *cmd, UART_HandleTypeDef *uart)
{
    char respuesta[80], texto[24];
    if (!strcmp(cmd, "LEER") || !strcmp(cmd, "L") ||
        !strcmp(cmd, "R") || !strcmp(cmd, "1")) {
        if (Adquirir_Temperatura()) {
            Temperatura_Texto(ultima_temperatura, texto);
            snprintf(respuesta, sizeof(respuesta), "MEDICION:%s C\r\n", texto);
            UART_Enviar(uart, respuesta);
        } else UART_Enviar(uart, "ERROR_SENSOR\r\n");
    } else if (!strcmp(cmd, "GUARDAR") || !strcmp(cmd, "S") ||
               !strcmp(cmd, "G") || !strcmp(cmd, "2")) {
        if (!medicion_valida) {
            UART_Enviar(uart, "ERROR_SIN_MEDICION\r\n");
            Pantalla_Estado("SIN MEDICION", ROJO);
            return;
        }
        Pantalla_Estado("GUARDANDO...", AMARILLO);
        FRESULT resultado = SD_GuardarTemperatura();
        if (resultado == FR_OK) {
            Pantalla_Estado("GUARDADO OK", VERDE);
            UART_Enviar(uart, "GUARDADO_OK\r\n");
        } else {
            Pantalla_Estado("ERROR SD", ROJO);
            snprintf(respuesta, sizeof(respuesta), "ERROR_SD:%d\r\n", (int)resultado);
            UART_Enviar(uart, respuesta);
        }
    } else if (!strcmp(cmd, "ESTADO") || !strcmp(cmd, "E")) {
        UART_Enviar(uart, medicion_valida ?
                    "MEDICION_DISPONIBLE\r\n" : "SIN_MEDICION\r\n");
    } else if (!strcmp(cmd, "VER") || !strcmp(cmd, "V")) {
        FRESULT resultado = SD_VerArchivo(uart);
        if (resultado != FR_OK) {
            snprintf(respuesta, sizeof(respuesta),
                     "ERROR_LECTURA_SD:%d\r\n", (int)resultado);
            UART_Enviar(uart, respuesta);
        }
    } else if (!strcmp(cmd, "PING")) {
        UART_Enviar(uart, "PONG\r\n");
    } else if (!strcmp(cmd, "H") || !strcmp(cmd, "?")) {
        UART_Enviar(uart, "LEER/L, GUARDAR/S, ESTADO/E, VER/V, PING\r\n");
    } else {
        UART_Enviar(uart, "COMANDO_DESCONOCIDO\r\n");
    }
}

static void Rx_RecibirByte(RX_Comando *estado, uint8_t byte)
{
    if (estado->listo) return;
    if (byte == '\r' || byte == '\n') {
        if (estado->longitud > 0) estado->listo = 1;
        return;
    }
    if (estado->longitud < CMD_LONGITUD - 1) {
        estado->datos[estado->longitud++] = (char)byte;
        estado->ultimo_byte_ms = HAL_GetTick();
    } else {
        estado->longitud = 0; // descartar comando demasiado largo
    }
}

static uint8_t Rx_Extraer(RX_Comando *estado, char *destino)
{
    // Acepta comandos con CR/LF; para una sola letra sin terminador,
    // espera 100ms, compatible con Nucleo 1 que envia 'L' o 'S'.
    if (!estado->listo &&
        !(estado->longitud == 1 &&
          (HAL_GetTick() - estado->ultimo_byte_ms >= 100))) return 0;
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    uint8_t n = estado->longitud;
    for (uint8_t i = 0; i < n; i++) destino[i] = estado->datos[i];
    destino[n] = '\0';
    estado->longitud = 0;
    estado->listo = 0;
    __set_PRIMASK(primask);
    return n > 0;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        Rx_RecibirByte(&rx_pc, byte_pc);
        HAL_UART_Receive_IT(&huart2, &byte_pc, 1);
    } else if (huart->Instance == USART3) {
        Rx_RecibirByte(&rx_n1, byte_n1);
        HAL_UART_Receive_IT(&huart3, &byte_n1, 1);
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        rx_pc.longitud = 0; rx_pc.listo = 0;
        HAL_UART_Receive_IT(&huart2, &byte_pc, 1);
    } else if (huart->Instance == USART3) {
        rx_n1.longitud = 0; rx_n1.listo = 0;
        HAL_UART_Receive_IT(&huart3, &byte_n1, 1);
    }
}
/* USER CODE END 0 */

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_USART2_UART_Init();
    MX_I2C1_Init();
    MX_USART3_UART_Init();
    MX_FATFS_Init();

    /* USER CODE BEGIN 2 */
    HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);
    // Esta pantalla no comparte SPI: dejarlo a ~312.5 kHz para SD.
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
    if (HAL_SPI_Init(&hspi1) != HAL_OK) Error_Handler();
    if (HAL_UART_Receive_IT(&huart2, &byte_pc, 1) != HAL_OK)
        Error_Handler();
    if (HAL_UART_Receive_IT(&huart3, &byte_n1, 1) != HAL_OK)
        Error_Handler();
    Pantalla_Inicio();
    sensor_disponible = AHT10_Iniciar();
    Pantalla_Estado(sensor_disponible ? "PRESIONE LEER" : "ERROR SENSOR",
                   sensor_disponible ? AMARILLO : ROJO);
    if (sensor_disponible) {
        UART_Enviar(&huart2, aht10_direccion == (0x38u << 1) ?
                   "AHT10 OK (0x38)\r\n" : "AHT10 OK (0x39)\r\n");
    } else {
        char error_aht[80];
        snprintf(error_aht, sizeof(error_aht),
                 "AHT10 ERROR I2C=%d HALERR=0x%08lX\r\n",
                 (int)aht10_ultimo_estado,
                 (unsigned long)HAL_I2C_GetError(&hi2c1));
        UART_Enviar(&huart2, error_aht);
    }
    UART_Enviar(&huart2,
        "\r\nNUCLEO 2 LISTA (AHT10)\r\nComandos: LEER, GUARDAR, ESTADO, VER, PING\r\n");
    /* USER CODE END 2 */

    while (1)
    {
        /* USER CODE BEGIN 3 */
        char comando[CMD_LONGITUD];
        if (Rx_Extraer(&rx_pc, comando))
            ProcesarComando(comando, &huart2);
        if (Rx_Extraer(&rx_n1, comando))
            ProcesarComando(comando, &huart3);
        /* USER CODE END 3 */
    }
}


void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK) Error_Handler();
}

static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LCD_RST_Pin|LD1_Pin|LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LD1_Pin */
  GPIO_InitStruct.Pin = LD1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_SS_Pin */
  GPIO_InitStruct.Pin = SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(SD_SS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}



void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
}
#endif
