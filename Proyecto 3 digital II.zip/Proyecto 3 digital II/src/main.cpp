
#include <Arduino.h>

#define CUSTOM_SETTINGS
#define INCLUDE_TERMINAL_MODULE
#include <DabbleESP32.h>

// Pines UART hacia Nucleo 1
#define RXD2 16
#define TXD2 17

#define BAUDRATE 115200

// UART2
HardwareSerial Nucleo(2);


// Enviar comando a Nucleo 1
void enviarComando(char comando)
{
    if (comando == 'l')
        comando = 'L';

    if (comando == 'g')
        comando = 'G';

    if (comando == 'L')
    {
        Nucleo.write('L');

        Serial.println("Lectura solicitada");
        Terminal.println("Comando L enviado");
    }
    else if (comando == 'G')
    {
        Nucleo.write('G');

        Serial.println("Guardado solicitado");
        Terminal.println("Comando G enviado");
    }
}


void setup()
{
    // Monitor serial
    Serial.begin(BAUDRATE);

    // Comunicacion UART con Nucleo 1
    Nucleo.begin(
        BAUDRATE,
        SERIAL_8N1,
        RXD2,
        TXD2
    );

    // Inicializar Bluetooth Dabble
   Serial.println("Iniciando BLE...");
   Dabble.begin("MiESP32");
   Serial.println("BLE iniciado");

    Serial.println("ESP32 iniciado");
    Serial.println("Dabble listo");
    Serial.println("UART2 iniciado");
}

void loop()
{
    // Procesar datos Bluetooth
    Dabble.processInput();

    // Recibir comandos desde Dabble
    while (Terminal.available())
    {
        char comando = Terminal.read();

        enviarComando(comando);
    }

    // Permitir pruebas desde PlatformIO
    while (Serial.available())
    {
        char comando = Serial.read();

        enviarComando(comando);
    }

    // Mostrar respuestas de Nucleo 1
    while (Nucleo.available())
    {
        char dato = Nucleo.read();
        Serial.write(dato);
    }
}
